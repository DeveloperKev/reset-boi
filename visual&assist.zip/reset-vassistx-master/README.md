# reset-vassistx

Resets the trial period for Visual Assist X.

This script does the following:
* Remove a temporary file "1489AFE4.TMP" in the user's temp directory used by VA 
* Remove a registry key "HKEY_CURRENT_USER\SOFTWARE\Licenses" used by VA

--
*Tested on build 10.9.2114.0. Other builds may be immune to this script.*
